<?php
session_start();
$conn = new mysqli("localhost","root","","block5_otilano");
?>