#include <stdio.h>
int sum (int a,int b){
int res;
sum = (a+b);
return res;
}
int main(){
int a,b,res;
printf("Enter the Value of A: ");
scanf("%d",&a);
printf("Enter the Value of B: ");
scanf("%d",&b);
res=(a,b);
return 0;
}





    