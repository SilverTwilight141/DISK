#include <stdio.h>
int for(int a){
int sum a;
for (a = 90; a<=100;i++){

return for;
}

int main(){
int a;

for (a = 90; a<=100){
printf("The Sum is %d",a);
}
}
return 0;
}

