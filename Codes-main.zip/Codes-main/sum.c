#include <stdio.h>
int sum (int a){
int res;
for (int a = 90; a<=100;a++){
res += a;
}
return res;
}
int main(){
int a,res;

res = sum(a);
printf("The Sum is %d",res);

return 0;
}

    