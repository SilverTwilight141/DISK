#include<stdio.h>
int average (int a,b,c,d){

int avg=(a+b+c+d)/4;

return average;
}
int main(){
 
 int a,b,c,d,average;
 printf("Enter A B C D:");
 scanf("%d %d %d %d",&a,&b,&c,&d);
 
 average=(a,b,c,d);
 printf("average %d",average);
 return 0;
 }
 
 
    