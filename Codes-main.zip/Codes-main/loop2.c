#include <stdio.h>
int sum (int a){
int res;
,
for (int a = 90; a<=100;i++){
res += i;
return sum;
}
int main(){
int a;

res = for(a = 90; a<=100;a+a+1){
printf("The Sum is %d",a);
}
return 0;
}

